
typedef struct {
  bool f_1;
  bool f_2;
  bool f_3;
  bool f_4;
  bool f_5;
} flameDigitalValue;

typedef struct {
  int f_1;
  int f_2;
  int f_3;
  int f_4;
  int f_5;
} flameAnalogValue;
